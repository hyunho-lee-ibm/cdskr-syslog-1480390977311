/*eslint-env node*/

//------------------------------------------------------------------------------
// node.js starter application for Bluemix
//------------------------------------------------------------------------------

// This application uses express as its web server
// for more info, see: http://expressjs.com
var express = require('express');

// cfenv provides access to your Cloud Foundry environment
// for more info, see: https://www.npmjs.com/package/cfenv
var cfenv = require('cfenv');

// create a new express server
var app = express();


// Deal with multi part responses (such as file uploads)
// The default for multer is to store files in memory, which is what we want
// for this application. It is only temporary storage until the file is parsed
// anyway.
var upload = require("multer")();


// Use body-parser to receive POST form requests
app.use(require("body-parser")());


// Use the async package
var async = require("async");



// serve the files out of ./public as our main files
app.use(express.static(__dirname + '/public'));

// get the app environment from Cloud Foundry
var appEnv = cfenv.getAppEnv();



// Connect to the database
var dbInfo = appEnv.services.timeseriesdatabase[0];

// If there is no MongoDB service, exit
if (dbInfo == undefined) {
	console.log("No time series database to use, I am useless without it.");
	process.exit(-1);
}

// The variable used to actually talk to the database. It starts
// as null until gives a usable value in the connect function.
var syslogCollection = null;
var dbConn;

// Connect to the database. dbInfo.credentials.url contains the user name
// and password required to connect to the database.
require('mongodb').connect(dbInfo.credentials.json_url, function(err, conn) {
	if (err) {
		console.log("Cannot connect to database " + dbInfo.credentials.json_url);
		console.log(err.stack);
		process.exit(-2);
	}
	
	dbConn = conn;
	
	console.log("Database OK");
	
	// Set the actual variable used to communicate with the collection. The collection
	// will be created if necessary.
	syslogCollection = conn.collection("syslog");
});


// Turn records into HTML for display
var records2HTML = function(records) {
	var res = "";   // The result HTML

	res += "<table border><tr><th>Host</th><th>Component</th><th>PID</th><th>Date</th><th>Message</th></tr>";
	
	for (var i=0; i<records.length; i++) {
		res += "<tr>";
	
		res += "<td>" + records[i].host + "</td>";
		res += "<td>" + records[i].component + "</td>";

		res += "<td>";
		if (records[i].pid != undefined) { res += records[i].pid; }
		res += "</td>";

		res += "<td>" + new Date(records[i].date) + "</td>";	
		res += "<td>" + records[i].msg + "</td>";		
	
		res += "</tr>";
	}

	
	res += "</table>";
	
	return res;
};

// To see the credentials, etc.
// app.get("/help", /* @callback */ function(req, res) {
//	res.send(JSON.stringify(appEnv.services.timeseriesdatabase[0]));
// });





// Insert data into the collection. If there is a next
// function, call it afterwards
var insertData = function(data, next) {
	
	// If the syslogCollection is not available yet,
	// wait a second and try again.
	if (syslogCollection === null) {
		setTimeout(function() {insertData(data, next);}, 1000);
		return ;
	}

	// Insert the data
	syslogCollection.insert(data, {safe: true}, function(err) {
		if (err) {   // Log errors
			console.log("Insertion error");
			console.log("Data:" + JSON.stringify(data));
			console.log("Stack:");
			console.log(err.stack);
		} else       // If no error, call next() (if there is one)
			if (next !== undefined)
				next();
	});
};


// Delete the database if requested
app.get("/delete.html", /* @callback */ function(req, res) {
	syslogCollection.drop().then(
		function() {
			// Recreate the collection
			syslogCollection = dbConn.collection("syslog");
			
			res.send('Records deleted</br><a href="index.html">Return to the upload page</a>');			
		},
		function(err) {
			res.send("ERROR!!!" + JSON.stringify(err));
		});
	
});


// upload.any() is used to handle any uploaded files
app.post("/send-syslog", upload.any(), function(req, res) {
	var string = req.files[0].buffer.toString('utf8');
	var lines = string.split("\n");
	var records = [];
	var now = new Date();
	
	// For every line
	for(var i=0; i<lines.length; i++) {
		var newRecord = {};
		
		// The message after the colon should be kept as one piece.
		var colon = lines[i].indexOf(": ");
		newRecord.msg = lines[i].substring(colon+2);
		var data = lines[i].substring(0,colon);
		
		// The information before the colon follows a strict format annd
		// can be further divided.
		var recordData = data.split(/[ \t]+/);
		newRecord.host = recordData[3];
		
		// The component can have a PID in it.
		if (recordData.length >= 5) {
			var componentData = recordData[4].split("[");
			newRecord.component = componentData[0];
			if (componentData.length > 1) {
				newRecord.pid = componentData[1].replace("]", "");
			}
		}
		
		// Note that the result of Date.parse() is a number, not a Date object.
		// Also, syslog files do not contain the year. This code assumes
		// it is the current year, unless that would put it in the future.
		
		var dateStr = recordData[0] + " " + recordData[1] + " " + now.getFullYear() + " " + recordData[2];		
		newRecord.date = Date.parse(dateStr);
		if (newRecord.date > now) {
			dateStr = recordData[0] + " " + recordData[1] + " " + (now.getFullYear()-1) + " " + recordData[2];
			newRecord.date = Date.parse(dateStr);

		}
		
		records[records.length] = newRecord;
	}
	
	insertData(records);

	res.send(records2HTML(records) + '<br /><a href="index.html">Return to the upload page</a>');
});




// Read data in the collection, run next on the result
var readData = function(filter, next) {
	// If the syslogCollection is not available yet,
	// wait a second and try again.
	if (syslogCollection === null) {
		setTimeout(function() {readData(filter, next);}, 1000);
		return ;
	}		
	// If we're successful, run next on each entry. If not, log
	// that fact.
	syslogCollection.find(filter, {}, function(err, cursor) {
		if (err) {
			console.log("Search error");
			console.log("Filter:" + JSON.stringify(filter));
			console.log("Stack:");
			console.log(err.stack);			
		} else
			cursor.toArray(/* @callback */ function(err, items) {
				next(items);
			});   // End of cursor.toArray		
	});   // End of userCollection.find	
};    // End of readData


app.get("/data", /* @callback */ function(req, res) {
	readData({}, function(allEntries) {
		res.send(allEntries);
	});
	
});





// Increment the count for a key in a structure. If the key
// is not there yet, create it with one.
var incrementKeyInStruct = function(struct, key) {
	if (struct[key] == undefined)
		struct[key] = 1;
	else
		struct[key] ++;
};


// Count how many times each host, component, and (host, component) pair appears in 
// the data, and return a structure with that information. Add the total number of events
var countStats = function(data) {
	var result = {
		host_n_component: {},
		host: {},
		component: {},
		total: data.length
	};

	for(var i=0; i<data.length; i++) {		
		incrementKeyInStruct(result.host_n_component, data[i].host + "," + data[i].component);
		incrementKeyInStruct(result.host, data[i].host);		
		incrementKeyInStruct(result.component, data[i].component);		
	}
	
	return result;
};



// Add numbers in a structure to the totals in a separate structure
var add2Total = function(source, totals) {
	var keys = Object.keys(source);
	
	for (var i=0; i<keys.length; i++) 	{
		if (totals[keys[i]] == undefined)
			totals[keys[i]] = source[keys[i]];
		else
			totals[keys[i]] += source[keys[i]];
	}
};




// Get the totals per host and per component
var getTotals = function(results) {
	var host = {};
	var component = {};
	var host_n_component = {};
	
	for(var i=0; i<results.length; i++) {
		add2Total(results[i].stats.host, host);
		add2Total(results[i].stats.component, component);		
		add2Total(results[i].stats.host_n_component, host_n_component);		
	}
		
	return {
		host: host,
		component: component,
		host_n_component: host_n_component
	};
};



// Get statistics about the syslog entries between two times
app.get("/stats/:from/:until/:divisions", function(req, res) {
	// Keep the from and until times as numbers.
	var from = parseInt(req.params.from, 10);
	var until = parseInt(req.params.until, 10);
	var divisions = parseInt(req.params.divisions, 10);
	
	// The length of each period in the results
	var periodLength = (until-from)/divisions;
	
	// calculate the periods for the result "buckets"
	var results = new Array(divisions);

	var tasks = new Array(divisions);

	for(var i=0; i<divisions; i++) {
		results[i] = {};   // Initialize to an object.
		
		results[i].from = from + i*periodLength;
		results[i].until = from + (i+1)*periodLength;
		
		var timeFilter = {
			date: {
				$gte: results[i].from,
			 	$lt: results[i].until
			}			
		};
		
		tasks[i] = function(next) {
			readData(this.filter, function(data) {
				this.result.stats = countStats(data);
				next();
			} . bind({result: this.result}));
		} . bind({
			i: i,
			filter: timeFilter,
			result: results[i]
		});
	}
	
	async.parallel(tasks, /* @callback */ function(err) {
		res.send(JSON.stringify({
			results: results,
			totals: getTotals(results)
		}));
	});

		
});






// start server on the specified port and binding host
app.listen(appEnv.port, '0.0.0.0', function() {

	// print a message when the server starts listening
  console.log("server starting on " + appEnv.url);
});
